cShareSystems.load_pas("Pieces Of 12", [
	"coui://ui/mods/cMaps_p12/systems/exodus_system.pas",
	"coui://ui/mods/cMaps_p12/systems/marshalls_lament.pas",
	"coui://ui/mods/cMaps_p12/systems/trident_lake.pas",
	"coui://ui/mods/cMaps_p12/systems/kingdoms_collide.pas",
	"coui://ui/mods/cMaps_p12/systems/team_arena.pas"
]);