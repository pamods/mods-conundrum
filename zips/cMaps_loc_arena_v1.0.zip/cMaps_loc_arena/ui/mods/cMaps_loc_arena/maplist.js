cShareSystems.load_pas("LoC: The Arena", [
	"coui://ui/mods/cMaps_loc_arena/systems/exodus_system.pas",
	"coui://ui/mods/cMaps_loc_arena/systems/iceage.pas",
	"coui://ui/mods/cMaps_loc_arena/systems/hot_platforms.pas",
	"coui://ui/mods/cMaps_loc_arena/systems/team_arena.pas",
	"coui://ui/mods/cMaps_loc_arena/systems/ccrossing.pas"
]);