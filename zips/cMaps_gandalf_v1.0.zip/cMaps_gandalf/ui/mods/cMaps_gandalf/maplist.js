cShareSystems.load_pas("Gandalf", [
	"coui://ui/mods/cMaps_gandalf/systems/1v1_arena.pas",
	"coui://ui/mods/cMaps_gandalf/systems/canyon_wars.pas",
	"coui://ui/mods/cMaps_gandalf/systems/iceage.pas",
	"coui://ui/mods/cMaps_gandalf/systems/prof_x.pas",
	"coui://ui/mods/cMaps_gandalf/systems/team_arena.pas"
]);